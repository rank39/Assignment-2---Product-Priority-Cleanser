# Product Priority Cleanser: OSAT Investigation / TestPAC

A web app that turns yield data into ranked, reviewable priorities. It was built for the BRUIN / TestPAC OSAT case (Apache and Odyssey memory chips) and works with any product yield matrices plus a solar/humidity file.

## What it does
- **Inputs & parsing:** upload or paste yield matrices (operators in rows, Day 1…N in columns) and a Solar Intensity / Humidity file. One click loads the built-in OSAT Investigation/TestPAC case data.
- **Prioritized findings:** ranks findings by a composite score (persistence, severity, product value, revenue impact) with evidence, evaluation checks and a High / Medium / Low recommendation.
- **Human review:** approve, change priority, rename, recategorize and add notes. Decisions are stored and re-applied to matching findings later.
- **Yield & weather dashboard:** daily yields, weather regression, operator z-scores, per-operator drill-down and TestPAC economics.
- **Review history:** decision register, system-vs-human diff log and a context summary.

## Run locally
```bash
npm install
npm run dev
```

## Deploy to GitHub Pages
1. Push this folder to the `main` branch of your repo.
2. In the repo, go to **Settings → Pages** and set **Source** to **GitHub Actions**.
3. The included workflow builds and publishes the site on every push to `main`.

## Notes
- Reviews are saved in the browser's local storage, so they stay on one device and browser.
- Operators are flagged when their average yield is at least 3 standard deviations below the mean of all operator averages (adjustable in Inputs).
- The gap versus ideal conditions is a modeled scenario, not an observed accounting loss.
